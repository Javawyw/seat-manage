<template>
  <div>
    <h2>User Login</h2>
    <form @submit.prevent="login">
      <div>
        <label for="userAccount">User Account:</label>
        <input type="text" id="userAccount" v-model="userAccount" required>
      </div>
      <div>
        <label for="userPassword">Password:</label>
        <input type="password" id="userPassword" v-model="userPassword" required>
      </div>
      <button type="submit">Login</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      userAccount: '',
      userPassword: ''
    };
  },
  methods: {
    login() {
      // Here you can send a request to your backend API to handle the login process
      console.log('User Account:', this.userAccount);
      console.log('Password:', this.userPassword);
      // Example of sending a request using axios:
       axios.post('/login', { userAccount: this.userAccount, userPassword: this.userPassword })
         .then(response => {
           console.log(response.data);
           // Handle successful login
         })
         .catch(error => {
           console.error('Error:', error);
           // Handle login failure
         });
    }
  }
};
</script>

<style scoped>
/* Add your custom styles here */
</style>