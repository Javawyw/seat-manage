<template>
  <div>
    <h2>Add User</h2>
    <form @submit.prevent="addUser">
      <div>
        <label for="username">Username:</label>
        <input type="text" id="username" v-model="username" required>
      </div>
      <div>
        <label for="gender">Gender:</label>
        <select id="gender" v-model="gender" required>
          <option value="0">Male</option>
          <option value="1">Female</option>
        </select>
      </div>
      <div>
        <label for="userAccount">User Account:</label>
        <input type="text" id="userAccount" v-model="userAccount" required>
      </div>
      <div>
        <label for="userPassword">Password:</label>
        <input type="password" id="userPassword" v-model="userPassword" required>
      </div>
      <div>
        <label for="phone">Phone:</label>
        <input type="tel" id="phone" v-model="phone" required>
      </div>
      <div>
        <label for="userRole">User Role:</label>
        <select id="userRole" v-model="userRole" required>
          <option value="0">Normal User</option>
          <option value="1">Administrator</option>
        </select>
      </div>
      <button type="submit">Add User</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      username: '',
      gender: 0,
      userAccount: '',
      userPassword: '',
      phone: '',
      userRole: 0
    };
  },
  methods: {
    addUser() {
      // Here you can send a request to your backend API to add the user
      console.log('Username:', this.username);
      console.log('Gender:', this.gender);
      console.log('User Account:', this.userAccount);
      console.log('Password:', this.userPassword);
      console.log('Phone:', this.phone);
      console.log('User Role:', this.userRole);
       //Example of sending a request using axios:
       axios.post('/addUser', {
         username: this.username,
         gender: this.gender,
         userAccount: this.userAccount,
         userPassword: this.userPassword,
         phone: this.phone,
         userRole: this.userRole
       })
       .then(response => {
         console.log(response.data);
         // Handle successful user addition
       })
       .catch(error => {
         console.error('Error:', error);
         // Handle user addition failure
       });
    }
  }
};
</script>

<style scoped>
/* Add your custom styles here */
</style>