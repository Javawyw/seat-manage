<template>
  <div>
    <h2>User List</h2>
    <table>
      <thead>
      <tr>
        <th>Username</th>
        <th>Gender</th>
        <th>User Account</th>
        <th>User Role</th>
        <th>Action</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="(user, index) in userList" :key="index">
        <td>{{ user.username }}</td>
        <td>{{ user.gender === 0 ? 'Male' : 'Female' }}</td>
        <td>{{ user.userAccount }}</td>
        <td>{{ user.userRole === 0 ? 'Normal User' : 'Administrator' }}</td>
        <td>
          <button @click="editUser(user)">Edit</button>
          <button @click="deleteUser(user)">Delete</button>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      userList: [] // This will be populated with data from your backend API
    };
  },
  methods: {
    editUser(user) {
      // Implement functionality to edit user
      console.log('Edit user:', user);
    },
    deleteUser(user) {
      // Implement functionality to delete user
      console.log('Delete user:', user);
    }
  }
};
</script>

<style scoped>
/* Add your custom styles here */
</style>