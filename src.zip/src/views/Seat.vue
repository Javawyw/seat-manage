<template>
  <div>
    <!-- Form for adding a seat -->
    <form @submit.prevent="addSeat">
      <input type="text" v-model="newSeat.name" placeholder="Seat Name">
      <button type="submit">Add Seat</button>
    </form>

    <!-- List of seats -->
    <ul>
      <li v-for="seat in seats" :key="seat.id">
        {{ seat.name }}
        <!-- Buttons for updating and deleting a seat -->
        <button @click="updateSeat(seat.id)">Update</button>
        <button @click="deleteSeat(seat.id)">Delete</button>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      seats: [],
      newSeat: {
        name: ''
      }
    };
  },
  mounted() {
    // Fetch seats when the component is mounted
    this.getSeats();
  },
  methods: {
    // Method to add a new seat
    addSeat() {
      axios.post('/add', this.newSeat)
          .then(response => {
            // Refresh seats after successful addition
            this.getSeats();
            // Clear input field
            this.newSeat.name = '';
          })
          .catch(error => {
            console.error('Error adding seat: ', error);
          });
    },
    // Method to update a seat
    updateSeat(seatId) {
      // Implement update logic
    },
    // Method to delete a seat
    deleteSeat(seatId) {
      // Implement delete logic
    },
    // Method to fetch all seats
    getSeats() {
      axios.get('/page')
          .then(response => {
            this.seats = response.data.data;
          })
          .catch(error => {
            console.error('Error fetching seats: ', error);
          });
    }
  }
};
</script>

<style>
/* Add your component styles here */
</style>